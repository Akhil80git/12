import { motion } from "motion/react";
import { 
  School, 
  Dumbbell, 
  ShoppingCart, 
  GraduationCap, 
  Code2, 
  Smartphone, 
  Search, 
  Palette, 
  Cloud, 
  ShieldCheck, 
  Cpu, 
  BarChart3,
  Youtube,
  Instagram,
  Github,
  ArrowRight,
  Cpu as CpuIcon
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const Navbar = () => {
  return (
    <nav className="fixed top-0 w-full z-50 bg-background/80 backdrop-blur-md border-b border-border/40">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
            <CpuIcon className="text-primary-foreground w-5 h-5" />
          </div>
          <span className="font-bold text-xl tracking-tight">Vertax Online</span>
        </div>
        <div className="hidden md:flex items-center gap-8">
          <a href="#services" className="text-sm font-medium hover:text-primary transition-colors">Services</a>
          <a href="#socials" className="text-sm font-medium hover:text-primary transition-colors">Connect</a>
          <a href="https://github.com/vertaxonline" target="_blank" rel="noreferrer" className="text-sm font-medium hover:text-primary transition-colors">GitHub</a>
        </div>
        <Button size="sm" className="rounded-full px-6">Get Started</Button>
      </div>
    </nav>
  );
};

const Hero = () => {
  return (
    <section className="relative pt-32 pb-20 overflow-hidden">
      <div className="absolute inset-0 -z-10 bg-[radial-gradient(45%_45%_at_50%_50%,var(--color-primary)_0%,transparent_100%)] opacity-[0.03] animate-pulse-slow" />
      <div className="container mx-auto px-4 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <Badge variant="secondary" className="mb-4 px-4 py-1 rounded-full text-xs font-semibold uppercase tracking-wider">
            Premium Digital Solutions
          </Badge>
          <h1 className="text-5xl md:text-7xl font-bold tracking-tight mb-6 bg-gradient-to-b from-foreground to-foreground/70 bg-clip-text text-transparent">
            Elevate Your Digital <br /> Presence with Vertax
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-10">
            We build high-performance school management systems, gym platforms, 
            e-commerce stores, and custom education portals tailored for your success.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Button size="lg" className="rounded-full px-8 h-12 text-base">
              View Our Services <ArrowRight className="ml-2 w-4 h-4" />
            </Button>
            <Button size="lg" variant="outline" className="rounded-full px-8 h-12 text-base">
              Contact Us
            </Button>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

const servicesList = [
  {
    title: "School Website",
    description: "Complete management systems with student portals, attendance, and result tracking.",
    icon: School,
    color: "bg-blue-500/10 text-blue-500"
  },
  {
    title: "Gym Website",
    description: "Member management, workout tracking, and subscription billing for fitness centers.",
    icon: Dumbbell,
    color: "bg-orange-500/10 text-orange-500"
  },
  {
    title: "E-Commerce",
    description: "Scalable online stores with secure payments and inventory management.",
    icon: ShoppingCart,
    color: "bg-green-500/10 text-green-500"
  },
  {
    title: "Education Portals",
    description: "LMS solutions for online courses, certifications, and interactive learning.",
    icon: GraduationCap,
    color: "bg-purple-500/10 text-purple-500"
  },
  {
    title: "Web Development",
    description: "Modern, responsive websites built with the latest tech stack like React and Next.js.",
    icon: Code2,
    color: "bg-cyan-500/10 text-cyan-500"
  },
  {
    title: "App Development",
    description: "Native and cross-platform mobile applications for iOS and Android.",
    icon: Smartphone,
    color: "bg-rose-500/10 text-rose-500"
  },
  {
    title: "SEO & Marketing",
    description: "Boost your visibility and reach with data-driven marketing strategies.",
    icon: Search,
    color: "bg-yellow-500/10 text-yellow-500"
  },
  {
    title: "UI/UX Design",
    description: "User-centric design that focuses on aesthetics and seamless interactions.",
    icon: Palette,
    color: "bg-indigo-500/10 text-indigo-500"
  },
  {
    title: "Cloud Solutions",
    description: "Secure and scalable cloud infrastructure for your growing business.",
    icon: Cloud,
    color: "bg-sky-500/10 text-sky-500"
  },
  {
    title: "Cyber Security",
    description: "Protect your digital assets with our advanced security protocols.",
    icon: ShieldCheck,
    color: "bg-emerald-500/10 text-emerald-500"
  },
  {
    title: "AI Integration",
    description: "Leverage the power of AI to automate and optimize your workflows.",
    icon: Cpu,
    color: "bg-violet-500/10 text-violet-500"
  },
  {
    title: "Data Analytics",
    description: "Turn your raw data into actionable insights with our analytics tools.",
    icon: BarChart3,
    color: "bg-amber-500/10 text-amber-500"
  }
];

const Services = () => {
  return (
    <section id="services" className="py-24 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Core Services</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            We provide a wide range of digital services to help businesses and 
            institutions thrive in the modern era.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {servicesList.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.05 }}
            >
              <Card className="h-full border-none shadow-sm hover:shadow-md transition-all group">
                <CardHeader>
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-4 ${service.color} group-hover:scale-110 transition-transform`}>
                    <service.icon className="w-6 h-6" />
                  </div>
                  <CardTitle className="text-xl">{service.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-sm leading-relaxed">
                    {service.description}
                  </CardDescription>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Socials = () => {
  const socialLinks = [
    {
      name: "YouTube",
      handle: "@vertaxonline",
      url: "https://youtube.com/vertaxonline",
      icon: Youtube,
      color: "hover:text-red-500"
    },
    {
      name: "Instagram",
      handle: "@vertaxonline",
      url: "https://instagram.com/vertaxonline",
      icon: Instagram,
      color: "hover:text-pink-500"
    },
    {
      name: "GitHub",
      handle: "vertaxonline",
      url: "https://github.com/vertaxonline",
      icon: Github,
      color: "hover:text-gray-400"
    }
  ];

  return (
    <section id="socials" className="py-24">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto bg-card border border-border/50 rounded-3xl p-8 md:p-12 shadow-xl">
          <div className="flex flex-col md:flex-row items-center justify-between gap-8">
            <div className="text-center md:text-left">
              <h2 className="text-3xl font-bold mb-4">Connect With Us</h2>
              <p className="text-muted-foreground">
                Follow us on social media for the latest updates, 
                tutorials, and open-source projects.
              </p>
            </div>
            <div className="flex flex-wrap justify-center gap-6">
              {socialLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.url}
                  target="_blank"
                  rel="noreferrer"
                  className={`flex flex-col items-center gap-2 group transition-all ${link.color}`}
                >
                  <div className="w-14 h-14 rounded-full bg-muted flex items-center justify-center group-hover:bg-muted/50 transition-colors">
                    <link.icon className="w-6 h-6" />
                  </div>
                  <span className="text-xs font-semibold uppercase tracking-wider">{link.name}</span>
                </a>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const Footer = () => {
  return (
    <footer className="py-12 border-t border-border/40 bg-muted/20">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center gap-2 mb-6">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <CpuIcon className="text-primary-foreground w-5 h-5" />
              </div>
              <span className="font-bold text-xl tracking-tight">Vertax Online</span>
            </div>
            <p className="text-muted-foreground max-w-sm mb-6">
              Your partner in digital transformation. We build the future 
              of web and mobile experiences.
            </p>
            <div className="flex gap-4">
              <Youtube className="w-5 h-5 text-muted-foreground hover:text-primary cursor-pointer" />
              <Instagram className="w-5 h-5 text-muted-foreground hover:text-primary cursor-pointer" />
              <Github className="w-5 h-5 text-muted-foreground hover:text-primary cursor-pointer" />
            </div>
          </div>
          <div>
            <h4 className="font-bold mb-6">Services</h4>
            <ul className="space-y-4 text-sm text-muted-foreground">
              <li className="hover:text-primary cursor-pointer">School Management</li>
              <li className="hover:text-primary cursor-pointer">Gym Platforms</li>
              <li className="hover:text-primary cursor-pointer">E-Commerce</li>
              <li className="hover:text-primary cursor-pointer">Education Portals</li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold mb-6">Company</h4>
            <ul className="space-y-4 text-sm text-muted-foreground">
              <li className="hover:text-primary cursor-pointer">About Us</li>
              <li className="hover:text-primary cursor-pointer">Contact</li>
              <li className="hover:text-primary cursor-pointer">Privacy Policy</li>
              <li className="hover:text-primary cursor-pointer">Terms of Service</li>
            </ul>
          </div>
        </div>
        <div className="pt-8 border-t border-border/40 flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-muted-foreground">
          <p>© 2026 Vertax Online. All rights reserved.</p>
          <div className="flex gap-8">
            <span>Built with ❤️ for the future.</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default function App() {
  return (
    <div className="min-h-screen bg-background text-foreground font-sans selection:bg-primary/20">
      <Navbar />
      <main>
        <Hero />
        <Services />
        <Socials />
      </main>
      <Footer />
    </div>
  );
}
